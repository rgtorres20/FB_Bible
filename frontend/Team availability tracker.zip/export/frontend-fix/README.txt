FIX for the frontend commit — one file is missing:

  frontend/manifest.webmanifest   (518 bytes, included here)

Commit it to exactly that path and push. (_ds_bundle.js in this folder is
byte-identical to what is already committed — ignore or overwrite, no harm.)

/health also reported support.js and _ds missing even though they are in the
repo — that means Vercel has NOT deployed the latest commit. After pushing,
check the Vercel dashboard (or the GitHub commit status) that a new deploy
ran and succeeded. Then:

  curl https://fb-bible-torro2.vercel.app/health   ->  frontend_ready: true
  open https://fb-bible-torro2.vercel.app          ->  the app
